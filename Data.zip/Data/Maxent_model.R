# Set working directory
getwd()
setwd("D:/USF_OneDrive/OneDrive - University of South Florida/HBB_Paper/ASCII")
list.files(pattern = "\\.asc$")

# Load necessary libraries
library(dismo)
library(ENMTools)
library(raster)
library(devtools)
library(ENMeval)
library(MASS)
library(sf)
library(usdm)
library(terra)
library(maxnet)
library(spThin)
library(rJavaEnv)
# Load environmental raster data for Nepal
bio1 <- raster("bio_1.asc")
bio2 <- raster("bio_2.asc")
bio3 <- raster("bio_3.asc")
bio4 <- raster("bio_4.asc")
bio5 <- raster("bio_5.asc")
bio6 <- raster("bio_6.asc")
bio7 <- raster("bio_7.asc")
bio8 <- raster("bio_8.asc")
bio9 <- raster("bio_9.asc")
bio10 <- raster("bio_10.asc")
bio11 <- raster("bio_11.asc")
bio12 <- raster("bio_12.asc")
bio13 <- raster("bio_13.asc")
bio14 <- raster("bio_14.asc")
bio15 <- raster("bio_15.asc")
bio16 <- raster("bio_16.asc")
bio17 <- raster("bio_17.asc")
bio18 <- raster("bio_18.asc")
bio19 <- raster("bio_19.asc")
elevation <- raster("elevation.asc")
forest <- raster("dist_forest.asc")
road <- raster("dist_road.asc")
watersources <- raster("dist_watersources.asc")
livestock <- raster("livestock.asc")
settlement<- raster("dist_settlement.asc")
agland<- raster("dist_agriculturalLand.asc")
ndvi<- raster("ndvi.asc")

# Stack the environmental data for Nepal
parameter <- stack(bio1, bio2, bio3, bio4, bio5, bio6, bio7, bio8, bio9, bio10,
                   bio11, bio12, bio13, bio14, bio15, bio16, bio17, bio18, bio19,
                   elevation, forest,  road, watersources, livestock, settlement, agland, ndvi )

# Set names for the layers
names(parameter) <- c("bio1", "bio2", "bio3", "bio4", "bio5", "bio6", "bio7",
                      "bio8", "bio9", "bio10", "bio11", "bio12", "bio13", 
                      "bio14", "bio15", "bio16", "bio17", "bio18", "bio19",
                      "elevation", "forest", "road", "watersources", "livestock", "settlement", "agland", "ndvi")

# Load occurrence data
occ_data <- read.csv("D:/USF_OneDrive/OneDrive - University of South Florida/HBB_Paper/Ursus_thibetanus_user.csv", header = TRUE)


thin_occ <- thin(
 loc.data = occ_data,
 lat.col = "latitude",
 long.col = "longitude",
 spec.col = "scientific_name",
 thin.par = 1,     # thinning distance in km
 reps = 1,
 locs.thinned.list.return = TRUE,
 out.dir = "thinned_occurrences",   # folder to save outputs
 out.base = "HBB_thin",             # base filename
 write.files = TRUE)

# First thinned replicate
thin_df <- thin_occ[[1]]

# Create vector from coordinates
occ_points <- vect(thin_df, geom = c("Longitude", "Latitude"),
                   crs = "EPSG:4326")   # WGS84 lat/lon

# Convert back to SpatVector
parameter <- projectRaster(parameter, crs = crs(occ_points))
# Convert old RasterBrick/Stack to terra SpatRaster
parameter <- rast(parameter)
# Perform colinearity test
ex <- raster::extract(parameter, occ_points)
# Convert to data frame
ex <- as.data.frame(ex)
# Remove rows with NA (VIF cannot handle NA)
ex <- na.omit(ex)

vif(ex)
vifstep(ex)


# Names of selected variables
sel_vars_full <- c("bio2", "bio6", "bio14", "bio15", "bio18", "bio19",
              "forest", "road", "watersources", "livestock", 
              "settlement", "agland", "ndvi")
sel_vars_bioclim<- c("bio2", "bio6", "bio14", "bio15", "bio18", "bio19")

  
# Subset raster stack (parameter = your original stack)
parameter_full <- subset(parameter, sel_vars_full)
parameter_bioclim<- subset(parameter, sel_vars_bioclim)





# 4. Create 40 km buffer around occurrences
# ---------------------------------------------------
nepal <- st_read("D:/USF_OneDrive/OneDrive - University of South Florida/HBB_Paper/Local Unit/Nepal_boundry_1.shp")
nepal <- st_transform(nepal, crs(occ_points))
crs(nepal)

occ_buffer <- buffer(occ_points, 
                     width = 30000)
occ_buffer<- project(occ_buffer, crs(occ_points))
plot(occ_buffer)

env_crop_full <- crop(parameter_full, nepal)

#env_crop_full <- terra::project(env_crop_full, "EPSG:4326")
env_crop_bioclim<- crop(parameter_bioclim, nepal)
#env_crop_bioclim <- terra::project(env_crop_bioclim, "EPSG:4326")


is.factor(env_crop_full)
is.factor(env_crop_bioclim)

# ---------------------------------------------------
# 5. Prepare presence and background data
# ---------------------------------------------------
occ_coords <- as.data.frame(geom(occ_points)[, c("x", "y")])
bg_points_full <- spatSample(env_crop_full, size = 10000, method="random", as.points=TRUE)
bg_points_bioclim<- spatSample(env_crop_bioclim, size = 10000, method="random", as.points=TRUE)
bg_coords_full <- as.data.frame(geom(bg_points_full)[,c("x","y")])
bg_coords_bioclim<- as.data.frame(geom(bg_points_bioclim)[,c("x","y")])

#Make it same crs
#occ_coords<- vect(occ_points, geom=c("x","y"), crs="EPSG:4326")
#bg_coords_full <- vect(bg_coords_full, geom=c("x","y"), crs="EPSG:4326")
#bg_coords_bioclim<- vect(bg_coords_bioclim, geom=c("x","y"), crs="EPSG:4326")

# 2. Define partitioning (random k-fold)
# 3. Checkerboard partitioning
#partition_full <- get.randomkfold(
  #occs = occ_coords,
  #bg = bg_coords_full, 2)

#partition_bioclim <-get.randomkfold(
  #occs = occ_coords,
  #bg = bg_coords_bioclim, 2)

# Tuning grid
#fc <- c("L","LQ","H","LQH","LQHP")
#rm <- c(1,2,3)
#tuning <- expand.grid(
 # fc = fc,
  #rm = rm,
  #stringsAsFactors = FALSE)
#tuning$fc<- as.character(tuning$fc)

set.seed(42)
Sys.setenv(JAVA_HOME = "C:/Users/nsuma/AppData/Local/Programs/Eclipse Adoptium/jdk-25.0.0.36-hotspot")
# 4. Run ENMevaluate with maxnet for Anthropogenic Environment Model
eval_full <- ENMevaluate(
  occs = occ_coords,
  envs = env_crop_full,
  bg = bg_coords_full,
  partitions = "randomkfold",
  partition.settings = list(kfolds = 2),
  tune.args = list(fc = c("L","LQ","LQH","LQHP"), rm = c(1,2,3) ),
  algorithm = "maxent.jar",
  parallel = FALSE, 
  #numCores = 8,
  doClamp = TRUE
)

# Save your evaluation objectM
save(eval_full, file = "FullModel.RData")


set.seed(42)
# 4. Run ENMevaluate with maxnet for Natural Environment Model 
eval_bioclim <- ENMevaluate(
  occs = occ_coords,
  envs = env_crop_bioclim,
  bg = bg_coords_bioclim,
  partitions = "randomkfold",
  partition.settings = list(kfolds = 2),
  tune.args = list(fc = c("L","LQ","LQH","LQHP"), rm = c(1,2,3) ),
  algorithm = "maxent.jar",
  parallel = FALSE, 
  #numCores = 8,
  doClamp = TRUE
)

# Save your evaluation objectM
save(eval_bioclim, file = "BioclimModel.RData")

