setwd("D:/USF_OneDrive/OneDrive - University of South Florida/HBB_Paper/ASCII")
m1 <- read.csv("SuitabilityByLULC_Bioclim.csv")
m2 <- read.csv("SuitabilityByLuULC_Full.csv")
m3 <- read.csv("StudyArea.csv")

m1$model <- "Natural Environment Model"
m2$model <- "Anthropogenic Environment Model"
m3$model <- "Study Area"
m3$Class_name<- "NA"
area_df <- rbind(m1, m2, m3)

library(dplyr)

area_df <- area_df %>%
  mutate(LULC_class = ifelse(LULC_class == "Waterbody", "Others", LULC_class)) %>%
  group_by(model, LULC_class) %>%
  summarise(Area_km2 = sum(Area_km2, na.rm = TRUE), .groups = "drop")

# Set order for plotting
area_df <- area_df %>%
  mutate(LULC_class = factor(
    LULC_class,
    levels = c("Forest", "Human-modified land", "Grassland", "Others")
  ))

area_df <- area_df %>%
  mutate(model = factor(
    model,
    levels = c("Study Area",
               "Natural Environment Model",
               "Anthropogenic Environment Model")
  ))

library(ggplot2)

plot_new <- ggplot(area_df, aes(x = LULC_class, y = Area_km2, fill = model)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  scale_fill_manual(values = c(
    "Natural Environment Model" = "#7570b3",
    "Anthropogenic Environment Model" = "#d95f02",
    "Study Area" = "#1b9e77"
  )) +
  labs(
    title = "Area by Land Use/Land Cover Class",
    x = "LULC Class",
    y = "Area (sq. km)",
    fill = "Legend"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    axis.text.x = element_text(angle = 30, hjust = 1),
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
    
    # Legend inside plot

    legend.position = c(0.8, 0.8),
    legend.background = element_rect(fill = "white", colour = "black"),
    legend.title = element_text(size = 11, face = "bold"),
    legend.text = element_text(size = 10)
  )

plot_new

ggsave(
  plot = plot_new,
  filename = "LULC_3models.png",
  width = 10,
  height = 8,
  dpi = 400
)

